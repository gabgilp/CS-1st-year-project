#include "stack.h"
#include "ijvm.h"

void push(stack_t stack, word_t word){
    return;
}

word_t pop(stack_t stack){
    return 0;
}